De source files zijn in de folder 'MuGen' terug te vinden

de 2 midifiles 
"CMajBassLine.mid"
"CMajBassLine2.mid"
zijn mogelijke inputs voor de basopgave-functie van het programma.
